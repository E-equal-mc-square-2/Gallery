let gallery = [];
let currentLightboxIndex = 0;
let displayedCount = 0;
const ITEMS_PER_LOAD = 12;
let isLoading = false;
let allLoaded = false;

async function fetchLatestTimestamp() {
    try {
        const response = await fetch('/public/latest.txt?t=' + Date.now());
        if (response.ok) {
            const timestamp = await response.text();
            const timestampEl = document.getElementById('latest-timestamp');
            if (timestamp && timestamp.trim()) {
                timestampEl.textContent = 'Updated: ' + timestamp.trim();
            } else {
                timestampEl.textContent = 'No uploads yet';
            }
        }
    } catch (error) {
        console.log('Could not fetch timestamp');
    }
}

async function refreshLatestPhoto() {
    const latestPhoto = document.getElementById('latest-photo');
    const noLatest = document.getElementById('no-latest');
    
    try {
        const response = await fetch('/public/latest.jpg?t=' + Date.now(), { method: 'HEAD' });
        if (response.ok) {
            latestPhoto.src = '/public/latest.jpg?t=' + Date.now();
            latestPhoto.style.display = 'block';
            noLatest.style.display = 'none';
        } else {
            latestPhoto.style.display = 'none';
            noLatest.style.display = 'flex';
        }
    } catch (error) {
        latestPhoto.style.display = 'none';
        noLatest.style.display = 'flex';
    }
    
    await fetchLatestTimestamp();
}

async function fetchGallery() {
    try {
        const response = await fetch('/public/gallery.json?t=' + Date.now());
        if (response.ok) {
            const data = await response.json();
            if (JSON.stringify(data) !== JSON.stringify(gallery)) {
                gallery = data;
                displayedCount = 0;
                allLoaded = false;
                document.getElementById('gallery-grid').innerHTML = '';
                loadMoreItems();
            }
        }
    } catch (error) {
        console.log('Could not fetch gallery');
    }
}

function createGalleryItem(photo, originalIndex) {
    const photoNumber = photo.replace('photo', '').replace('.jpg', '');
    const item = document.createElement('div');
    item.className = 'gallery-item';
    item.onclick = () => openLightbox(originalIndex);
    item.innerHTML = `
        <img src="/public/${photo}?t=${Date.now()}" alt="Photo ${photoNumber}" loading="lazy">
        <span class="photo-number">#${photoNumber}</span>
    `;
    return item;
}

function loadMoreItems() {
    if (isLoading || allLoaded || !gallery || gallery.length === 0) return;
    
    isLoading = true;
    const galleryGrid = document.getElementById('gallery-grid');
    const emptyGallery = document.getElementById('empty-gallery');
    const loadingIndicator = document.getElementById('loading-indicator');
    
    if (gallery.length === 0) {
        galleryGrid.style.display = 'none';
        emptyGallery.style.display = 'flex';
        isLoading = false;
        return;
    }
    
    galleryGrid.style.display = 'grid';
    emptyGallery.style.display = 'none';
    
    const reversedGallery = [...gallery].reverse();
    const startIndex = displayedCount;
    const endIndex = Math.min(startIndex + ITEMS_PER_LOAD, reversedGallery.length);
    
    if (loadingIndicator) {
        loadingIndicator.style.display = 'flex';
    }
    
    setTimeout(() => {
        for (let i = startIndex; i < endIndex; i++) {
            const photo = reversedGallery[i];
            const originalIndex = gallery.length - 1 - i;
            const item = createGalleryItem(photo, originalIndex);
            galleryGrid.appendChild(item);
        }
        
        displayedCount = endIndex;
        
        if (displayedCount >= reversedGallery.length) {
            allLoaded = true;
        }
        
        if (loadingIndicator) {
            loadingIndicator.style.display = 'none';
        }
        
        isLoading = false;
    }, 100);
}

function setupInfiniteScroll() {
    const sentinel = document.getElementById('scroll-sentinel');
    if (!sentinel) return;
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting && !isLoading && !allLoaded) {
                loadMoreItems();
            }
        });
    }, {
        root: null,
        rootMargin: '200px',
        threshold: 0
    });
    
    observer.observe(sentinel);
}

function openLightbox(index) {
    currentLightboxIndex = index;
    const lightbox = document.getElementById('lightbox');
    const lightboxImg = document.getElementById('lightbox-img');
    const lightboxTitle = document.getElementById('lightbox-title');
    
    const photo = gallery[index];
    const photoNumber = photo.replace('photo', '').replace('.jpg', '');
    
    lightboxImg.src = '/public/' + photo + '?t=' + Date.now();
    lightboxTitle.textContent = 'Photo #' + photoNumber;
    lightbox.classList.add('active');
    
    document.body.style.overflow = 'hidden';
}

function closeLightbox() {
    const lightbox = document.getElementById('lightbox');
    lightbox.classList.remove('active');
    document.body.style.overflow = '';
}

function navigateLightbox(direction) {
    currentLightboxIndex += direction;
    
    if (currentLightboxIndex < 0) {
        currentLightboxIndex = gallery.length - 1;
    } else if (currentLightboxIndex >= gallery.length) {
        currentLightboxIndex = 0;
    }
    
    openLightbox(currentLightboxIndex);
}

document.addEventListener('DOMContentLoaded', function() {
    refreshLatestPhoto();
    fetchGallery();
    setupInfiniteScroll();
    
    setInterval(refreshLatestPhoto, 2000);
    setInterval(fetchGallery, 3000);
    
    const lightbox = document.getElementById('lightbox');
    const closeBtn = document.querySelector('.lightbox-close');
    const prevBtn = document.querySelector('.lightbox-prev');
    const nextBtn = document.querySelector('.lightbox-next');
    
    closeBtn.addEventListener('click', closeLightbox);
    prevBtn.addEventListener('click', () => navigateLightbox(-1));
    nextBtn.addEventListener('click', () => navigateLightbox(1));
    
    lightbox.addEventListener('click', function(e) {
        if (e.target === lightbox) {
            closeLightbox();
        }
    });
    
    document.addEventListener('keydown', function(e) {
        if (!lightbox.classList.contains('active')) return;
        
        if (e.key === 'Escape') closeLightbox();
        if (e.key === 'ArrowLeft') navigateLightbox(-1);
        if (e.key === 'ArrowRight') navigateLightbox(1);
    });
});
